var shuffleSequence = seq("intro",  "instructions", sepWith("sep", seq( "practice", rshuffle(startsWith("target"), startsWith("catch")), "outro")));


var defaults = [
    "Separator", {
        hideProgressBar: false,
        transfer: 1000,
        normalMessage: "Please wait for the next question.",
        errorMessage: "Wrong. Please wait for the next question."
    },
    "DashedSentence", {
        mode: "self-paced reading"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Use number keys or click boxes to answer.",
        leftComment: "(Bad)", rightComment: "(Good)"
    },
    "Question", {
        hasCorrect: true
    },
    "Message", {
        hideProgressBar: true,
        transfer: "keypress"
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        checkedValue: "yes"
    },
    "RangeForm", {
        hideProgressBar: true,
    }
];

var slider_style = "-webkit-appearance: none; width:150px; background:#d3d3d3; height: 4px;outline: none;";

var construct_dialog = function(context, minus_trigger, plus_trigger) {
    var context = "<p style='font-size:20px;'> <b>" + context + "</b></p><br>";
    var m_t = "<div class='slidecontainer'> <span style='font-size:20px;'> &emsp; &emsp;" + minus_trigger + " </span> &emsp; <span style='float:right;'> least acceptable <input style=' "+slider_style+"' type='range' min='1' max='100' class='slider' name='minus_trigger' id='minus_trigger'> most acceptable </span> </div> <br><br>";    
    var p_t = "<div class='slidecontainer'> <span style='font-size:20px;'> &emsp; &emsp;" + plus_trigger + " </span> &emsp; <span style='float:right;'> least acceptable <input style=' "+slider_style+"' type='range' min='1' max='100' class='slider' name='plus_trigger' id='plus_trigger'> most acceptable</span> </div> <br>";
    
    var rand = Math.random();
    if(rand < 0.5) {
        return [context, m_t, p_t].join("");
    } else {
        return [context, p_t, m_t].join("");
    };
    
};

var items = [

    ["sep", "Separator", { }],
    
    ["intro", "Form", { html: { include: "example_intro.html" } } ],
    ["instructions", "Form", { html: { include: "instructions.html" } } ],
    ["outro", "Form", { continueMessage: "Click here to end the survey", html: { include: "example_outro.html" } } ],
    
    ["practice", "RangeForm", {html: construct_dialog("What did Sandra and Charlotte do last weekend?", "They went to the movies.", "She went to the movies." )}],
    ["practice", "RangeForm", {html: construct_dialog("What did Henry do on vacation?", "He went to the beach.", "He visited his parent's house in the country." )}],
    ["practice", "RangeForm", {html: construct_dialog("Where did Rosie put the plants?", "She put them in the box with the books.", "She put it in the box with the books." )}],
    
    ["catch", "RangeForm", {html: construct_dialog("My father bought a new TV recently.", "We think he spent too much money on it.", "We think she spent too much money on it." )}],
["catch", "RangeForm", {html: construct_dialog("The local priest asked for donations for a food bank.", "My family gave him lots of money.", "My family gave her lots of money." )}],
["catch", "RangeForm", {html: construct_dialog("Two years ago, our uncle moved to a different city.", "We miss him very badly.", "We miss her very badly." )}],
["catch", "RangeForm", {html: construct_dialog("Last week, my brother found $20 on the sidewalk.", "I said I think he should donate it to charity.", "I said I thought she should donate it to charity." )}],
["catch", "RangeForm", {html: construct_dialog("Yesterday, a nun visited our school.", "We heard her speak in our class on world religion.", "We heard him speak in our class on world religion." )}],
["catch", "RangeForm", {html: construct_dialog("Last year, my aunt visited us from Canada.", "She brought a big jar of maple syrup.", "He brought a big jar of maple syrup." )}],
["catch", "RangeForm", {html: construct_dialog("My mother bought a new car recently.", "We think she got it for a good price.", "We think he got it for a good price." )}],
["catch", "RangeForm", {html: construct_dialog("Three years ago, my sister started college.", "This year, she is going to graduate early.", "This year, he is going to graduate early." )}],

[["target_possibility_state_change_positive",370], "RangeForm", {html: construct_dialog("Gail was weeding the garden yesterday.", "Today, she might be planting flowers.", "Today, she might have finished weeding it." )}],
[["target_possibility_state_change_neutral",370], "RangeForm", {html: construct_dialog("What's new with Gail?", "She might be weeding the garden.", "She might have finished weeding the garden." )}],
[["target_possibility_cleft_positive",323], "RangeForm", {html: construct_dialog("Marina built something last night.", "She might have built a box.", "It might have been a box that she built." )}],
[["target_possibility_cleft_neutral",323], "RangeForm", {html: construct_dialog("What did Marina do last night?", "She might have built a box.", "It might have been a box that she built." )}],
[["target_possibility_only_positive",304], "RangeForm", {html: construct_dialog("Heba left for the town pool.", "It's possible on the way she decided to go to the park.", "It's possible on the way, she decided to go only there." )}],
[["target_possibility_only_neutral",304], "RangeForm", {html: construct_dialog("What did Heba do yesterday.", "It's possible she went to the pool.", "It's possible she went only to the pool." )}],
[["target_possibility_again_positive",379], "RangeForm", {html: construct_dialog("Jackson went to Disneyworld last spring.", "This spring, it's possible he will go to Universal Studios.", "This spring, it's possible he will go there again." )}],
[["target_possibility_again_neutral",379], "RangeForm", {html: construct_dialog("What will Jackson do this spring?", "It's possible he will go to Disneyworld.", "It's possible he will go to Disneyworld again." )}],
[["target_possibility_back_positive",362], "RangeForm", {html: construct_dialog("Mariam went to Florida last summer. What about this summer?", "Maybe she went to Florida.", "Maybe she went back to Florida." )}],
[["target_possibility_back_neutral",362], "RangeForm", {html: construct_dialog("What did Mariam do last summer?", "Maybe she went to Florida.", "Maybe she went back to Florida." )}],
[["target_possibility_state_change_positive",371], "RangeForm", {html: construct_dialog("Bella was cleaning the attic yesterday.", "Maybe today she is sweeping the garage.", "Maybe today she finished cleaning it." )}],
[["target_possibility_state_change_neutral",371], "RangeForm", {html: construct_dialog("What's up with Bella?", "Maybe she is sweeping the garage.", "Maybe she finished cleaning the attic." )}],
[["target_possibility_still_positive",376], "RangeForm", {html: construct_dialog("In the morning, Martin was painting a birdhouse.", "Maybe in the afternoon he was trimming the hedges.", "Maybe in the afternoon he was still painting it." )}],
[["target_possibility_still_neutral",376], "RangeForm", {html: construct_dialog("What is Martin up to this afternoon?", "Maybe he is painting a birdhouse.", "Maybe he is still painting a birdhouse." )}],
[["target_possibility_accomplishment_positive",337], "RangeForm", {html: construct_dialog("Rashida is looking for her favorite mug.", "Maybe she's getting frustrated looking for it.", "Maybe she found it under the sofa." )}],
[["target_possibility_accomplishment_neutral",337], "RangeForm", {html: construct_dialog("What's new with Rashida?", "Maybe she broke her favorite mug.", "Maybe she found her favorite mug." )}],
[["target_possibility_emotive_positive",331], "RangeForm", {html: construct_dialog("Isabella took Zayn's favorite toy car.", "Maybe he suspects that she took it.", "Maybe he's upset that she took it." )}],
[["target_possibility_emotive_neutral",331], "RangeForm", {html: construct_dialog("What's up with Zayn?", "Maybe he suspects that Isabella took his favorite toy car.", "Maybe he's mad that Isabella took his favorite toy car." )}],
[["target_possibility_again_positive",378], "RangeForm", {html: construct_dialog("Rex went to the mountains last summer.", "This summer, he might have gone to the beach.", "This summer, he might have gone there again." )}],
[["target_possibility_again_neutral",378], "RangeForm", {html: construct_dialog("What did Rex do last summer?", "He might have gone to the mountains.", "He might have gone to the mountains again." )}],
[["target_possibility_even_positive",308], "RangeForm", {html: construct_dialog("Kayla's team played hard in the state cup.", "It's possible they made it to the finals.", "It's possible they even made it to the finals." )}],
[["target_possibility_even_neutral",308], "RangeForm", {html: construct_dialog("How did Kayla's team do in the state cup?", "It's possible they made it to the finals.", "It's possible they even made it to the finals." )}],
[["target_possibility_possessive_positive",345], "RangeForm", {html: construct_dialog("Roderick got a new computer for work.", "He might have asked the IT specialist about the best way to set up a new computer.", "He might have asked the IT specialist about the best way to set up his new computer." )}],
[["target_possibility_possessive_neutral",345], "RangeForm", {html: construct_dialog("What did Roderick do this morning?", "He might have asked the IT specialist about the best way to set up a new computer.", "He might have asked the IT specialist about the best way to set up his new computer." )}],
[["target_possibility_even_positive",309], "RangeForm", {html: construct_dialog("Tariq studied hard for his test.", "It's possible he got an A on it.", "It's possible he even got an A on it." )}],
[["target_possibility_even_neutral",309], "RangeForm", {html: construct_dialog("How did Tariq do on the final exam?", "It's possible he got an A.", "It's possible he even got an A." )}],
[["target_possibility_definite_det_positive",351], "RangeForm", {html: construct_dialog("There are four families and a couple in Tomer's apartment building.", "It's possible families stay in the building for a long time.", "It's possible the couple will stay for a long time." )}],
[["target_possibility_definite_det_neutral",351], "RangeForm", {html: construct_dialog("Tomer moved to a new apartment building last year.", "It's possible families stay in the building for a long time.", "It's possible the couple will stay in the building for a long time." )}],
[["target_conditionals_back_positive",270], "RangeForm", {html: construct_dialog("Adele was in New York last week.", "If she is hanging out there this week, she'll visit with friends. ", "If she flies back there this week, she'll visit her friends." )}],
[["target_conditionals_back_neutral",270], "RangeForm", {html: construct_dialog("What is Adele up to?", "If she flies to New York, she'll spend time with friends.", "If she flies back to New York, she'll spend time with friends." )}],
[["target_conditionals_cleft_positive",223], "RangeForm", {html: construct_dialog("Mario ordered a drink at the bar.", "If he got a margarita, he'll be feeling tipsy.", "If it was a margarita that he got, he'll be feeling tipsy." )}],
[["target_conditionals_cleft_neutral",223], "RangeForm", {html: construct_dialog("How is Mario doing?", "If he ordered a margarita, he'll be feeling tipsy.", "If it was a margarita that he ordered, he'll be feeling tipsy." )}],
[["target_conditionals_only_positive",204], "RangeForm", {html: construct_dialog("Greta went to the dog park.", "If she then decided to go to the track, she'll be there now.", "If she decided to go only there, she'll be there now." )}],
[["target_conditionals_only_neutral",204], "RangeForm", {html: construct_dialog("What's Greta doing?", "If she decided to go to the dog park, she'll be there now.", "If she decided to only go to the dog park, she'll be there now." )}],
[["target_conditionals_still_positive",279], "RangeForm", {html: construct_dialog("Earlier, Orlando was playing basketball with friends.", "If he's stretching now, he'll be in a good mood.", "If he's still playing, he'll be in a good mood." )}],
[["target_conditionals_still_neutral",279], "RangeForm", {html: construct_dialog("How's Orlando doing?", "If he's playing basketball, he'll be a good mood.", "If he's still playing basketball, he'll be in a good mood." )}],
[["target_conditionals_again_positive",262], "RangeForm", {html: construct_dialog("Bella went to the mountains last winter.", "If she spends time there this winter, she'll be happy.", "If she goes again this year, she'll be happy." )}],
[["target_conditionals_again_neutral",262], "RangeForm", {html: construct_dialog("How is Bella feeling after her vacation?", "If she went to the mountains, she'll be happy.", "If she went to the mountains again, she'll be happy." )}],
[["target_conditionals_back_positive",271], "RangeForm", {html: construct_dialog("Aisha was in Philadelphia last week.", "If she spends time there this week, she'll visit the museum.", "If she goes back there this week, she'll visit the museum." )}],
[["target_conditionals_back_neutral",271], "RangeForm", {html: construct_dialog("What is Aisha up to this weekend?", "If she goes to Philadelphia, she'll visit the museum.", "If she goes back to Philadelphia, she'll visit the museum." )}],
[["target_conditionals_stateChange_positive",276], "RangeForm", {html: construct_dialog("Aniya was cleaning the attic.", "If she's in the kitchen, she's probably eating lunch now.", "If she stopped, she's probably eating lunch now." )}],
[["target_conditionals_stateChange_neutral",276], "RangeForm", {html: construct_dialog("What is Aniya up to?", "If she's in the kitchen, she's probably eating lunch now.", "If she stopped cleaning the attic, she's probably eating lunch now." )}],
[["target_conditionals_accomplishment_positive",237], "RangeForm", {html: construct_dialog("Valeria is taking her Physics test.", "If she enjoys taking it, she will in a good mood.", "If she passes it, she'll be in a good mood." )}],
[["target_conditionals_accomplishment_neutral",237], "RangeForm", {html: construct_dialog("How is Valeria doing?", "If she took an exam, she will be relieved.", "If she passes an exam, she will be relieved." )}],
[["target_conditionals_emotive_positive",231], "RangeForm", {html: construct_dialog("Leo stole Daisy's blender.", "If she suspects that he stole it, she's not letting on.", "If she's angry that he stole it, she's not letting on." )}],
[["target_conditionals_emotive_neutral",231], "RangeForm", {html: construct_dialog("What's up with Leo and Daisy?", "If she suspects he stole her blender, she's not letting on.", "If she's angry he stole her blender, she's not letting on." )}],
[["target_conditionals_still_positive",278], "RangeForm", {html: construct_dialog("In the morning, Norm was working on a report. ", "If he's editing it now, he'll be concentrating.", "If he's still working on it, he'll be concentrating." )}],
[["target_conditionals_still_neutral",278], "RangeForm", {html: construct_dialog("How's Norm doing?", "If he's working on his report, he'll be concentrating.", "If he's still working on his report, he'll be concentrating." )}],
[["target_conditionals_even_positive",208], "RangeForm", {html: construct_dialog("Cullen ran hard at the track meet.", "If he places, he'll be happy.", "If he even places he'll be happy." )}],
[["target_conditionals_even_neutral",208], "RangeForm", {html: construct_dialog("How does Cullen feel about his performance at the track meet?", "If he places, he'll be happy.", "If he even places, he'll be happy." )}],
[["target_conditionals_possessive_positive",245], "RangeForm", {html: construct_dialog("Alberto recently got a new down coat.", "If he brings a coat skiing, he'll stay warm.", "If he brings his coat skiing, he'll stay warm." )}],
[["target_conditionals_possessive_neutral",245], "RangeForm", {html: construct_dialog("How does Alberto feel about his upcoming ski trip?", "If he brings a down coat, he'll stay warm.", "If he brings his down coat, he'll stay warm." )}],
[["target_conditionals_even_positive",209], "RangeForm", {html: construct_dialog("Natasha studied hard for her exam.", "If she gets a B, she'll be happy.", "If she even gets a B, she'll be happy." )}],
[["target_conditionals_even_neutral",209], "RangeForm", {html: construct_dialog("How does Natasha feel about her exam?", "If she gets a B, she'll be happy.", "If she even gets a B, she'll be happy." )}],
[["target_conditionals_definite_positive",251], "RangeForm", {html: construct_dialog("On Brooke's team there are three mechanics and a forklift operator.", "If mechanics are happy, they will work hard.", "If the forklift operator is happy, they will work hard." )}],
[["target_conditionals_definite_neutral",251], "RangeForm", {html: construct_dialog("What has Brooke learned about her team at work?", "If mechanics are happy, they will work hard.", "If the forklift operator is happy, they will work hard." )}],
[["target_question_state_change_positive",470], "RangeForm", {html: construct_dialog("Travis was fixing the fence when it started to rain.", "Did he put on a rain jacket?", "Did he finish fixing the fence?" )}],
[["target_question_state_change_neutral",470], "RangeForm", {html: construct_dialog("Travis was outside when it started to rain.", "Did he put on a rain jacket?", "Did he finish fixing the fence?" )}],
[["target_question_cleft_positive",423], "RangeForm", {html: construct_dialog("Suhas left something at work.", "Did he leave his laptop behind?", "Was it his laptop that he left behind?" )}],
[["target_question_cleft_neutral",423], "RangeForm", {html: construct_dialog("Suhas is annoyed with himself.", "Did he leave his laptop at work?", "Was it his laptop that he left at work?" )}],
[["target_question_only_positive",404], "RangeForm", {html: construct_dialog("Tanya likes horror movies.", "Does she watch them a lot?", "Does she only like horror movies?" )}],
[["target_question_only_neutral",404], "RangeForm", {html: construct_dialog("Tanya watches a ton of movies.", "Does she like horror movies?", "Does she only like horror movies?" )}],
[["target_question_again_positive",479], "RangeForm", {html: construct_dialog("Riley went to Disney Land last summer.", "Did she go to a resort this summer?", "Did she go again this summer?" )}],
[["target_question_again_neutral",479], "RangeForm", {html: construct_dialog("Riley had an awesome summer.", "Did she visit Disney Land?", "Did she visit Disney Land again?" )}],
[["target_question_back_positive",462], "RangeForm", {html: construct_dialog("Conrad was in Pittsburg last year.", "Is he going to be spending time there next year?", "Is he going back there next year?" )}],
[["target_question_back_neutral",462], "RangeForm", {html: construct_dialog("Conrad is travelling a lot these days.", "Is he going to Pittsburg next year?", "Is he going back to Pittsburg next year?" )}],
[["target_question_state_change_positive",471], "RangeForm", {html: construct_dialog("Nolan was on a hike when he heard thunder.", "Did he look for lightning?", "Did he stop hiking?" )}],
[["target_question_state_change_neutral",471], "RangeForm", {html: construct_dialog("Nolan was outside when he heard thunder.", "Did he look for lightning?", "Did he stop hiking?" )}],
[["target_question_still_positive",476], "RangeForm", {html: construct_dialog("Natasha was writing a report after lunch.", "At 2:00 was she editing it?", "At 2:00, was she still writing the report?" )}],
[["target_question_still_neutral",476], "RangeForm", {html: construct_dialog("Natasha had lots of work today.", "At 2:00, was she writing her report?", "At 2:00, was she still writing her report?" )}],
[["target_question_accomplishment_positive",437], "RangeForm", {html: construct_dialog("Hannah took her Physics exam last weekend.", "Did she study hard for it?", "Did she pass it?" )}],
[["target_question_accomplishment_neutral",437], "RangeForm", {html: construct_dialog("Hannah was very busy last week in school.", "Did she study hard for an exam?", "Did she pass an exam?" )}],
[["target_question_emotive_factive_positive",431], "RangeForm", {html: construct_dialog("Akash took Franny's hat.", "Does she suspect that he took it?", "Is she annoyed that he took it?" )}],
[["target_question_emotive_factive_neutral",431], "RangeForm", {html: construct_dialog("Franny is talking to Akash.", "Does she suspect that he stole her hat?", "Is she annoyed that he stole her hat?" )}],
[["target_question_again_positive",478], "RangeForm", {html: construct_dialog("Avi went to the beach last summer.", "Did he spend time there this summer?", "Did he go again this summer?" )}],
[["target_question_again_neutral",478], "RangeForm", {html: construct_dialog("Avi had a great summer.", "Did he go to the beach?", "Did he go to the beach again?" )}],
[["target_question_even_positive",408], "RangeForm", {html: construct_dialog("Tanya ran extremely fast in the race.", "Did she beat her personal record.", "Did she even beat her personal record?" )}],
[["target_question_even_neutral",408], "RangeForm", {html: construct_dialog("Tanya ran in a race last weekend.", "Did she beat her personal record?", "Did she even beat her personal record?" )}],
[["target_question_possessive_positive",445], "RangeForm", {html: construct_dialog("Irene got a new wifi modem.", "Has she set up a modem before?", "Has she set up her modem yet?" )}],
[["target_question_possessive_neutral",445], "RangeForm", {html: construct_dialog("Irene knows that wifi modems can be difficult to set up.", "Has she set up a modem before?", "Has she set up her modem already?" )}],
[["target_question_even_positive",409], "RangeForm", {html: construct_dialog("James' basketball team is one of the best in the league.", "Did they make it to the championships?", "Did they even make it to the championships?" )}],
[["target_question_even_neutral",409], "RangeForm", {html: construct_dialog("James' is playing basketball this year.", "Did his team make it to the championships?", "Did his team even make it to the championships?" )}],
[["target_question_definite_det_positive",451], "RangeForm", {html: construct_dialog("There are five mechanics and a forklift operator on Ira's shift.", "Do mechanics like working the shift?", "Does the forklift operator like working the shift?" )}],
[["target_question_definite_det_neutral",451], "RangeForm", {html: construct_dialog("Ira just got assigned to a new shift at his factory.", "Do mechanics like working the shift?", "Does the forklift operator like the shift?" )}],
[["target_negation_question_positive",560], "RangeForm", {html: construct_dialog("Someone stole some cookies that John just baked.", "He doesn't concern himself wondering if they were caught.", "He doesn't concern himself wondering who did it." )}],
[["target_negation_question_neutral",560], "RangeForm", {html: construct_dialog("John is thinking about some cookies he just baked.", "He doesn't concern himself wondering if someone stole them.", "He doesn't concern himself wondering who stole them." )}],
[["target_negation_back_positive",570], "RangeForm", {html: construct_dialog("Claire visited family in California last Christmas. But flights are expensive now.", "So she isn't going there this Christmas.", "So she isn't going back there this Christmas." )}],
[["target_negation_back_neutral",570], "RangeForm", {html: construct_dialog("Claire saw that flights are expensive.", "So she isn't going to California for Christmas.", "So she isn't going back to California for Christmas." )}],
[["target_negation_cleft_positive",529], "RangeForm", {html: construct_dialog("Tyler forgot something on the airplane.", "He didn't remember to take his wallet with him.", "It was his wallet that he didn't remember to take with him." )}],
[["target_negation_cleft_neutral",529], "RangeForm", {html: construct_dialog("Why is Tyler so frustrated?", "He didn't remember to take his wallet with him.", "It was his wallet that he didn't remember to take with him." )}],
[["target_negation_possessive_positive",553], "RangeForm", {html: construct_dialog("Recently, Bill got a new water bottle. He went on a bike ride over the weekend.", "But he didn't take a water bottle with him.", "But he didn't take his water bottle with him." )}],
[["target_negation_possessive_neutral",553], "RangeForm", {html: construct_dialog("Why did Bill get thirsty on his bike ride?", "He didn't take a water bottle with him.", "He didn't take his water bottle with him." )}],
[["target_negation_again_positive",586], "RangeForm", {html: construct_dialog("Roger went skiing last winter.", "But this winter, he didn't spend any time at the ski resort.", "But this winter, he didn't go to the ski resort again." )}],
[["target_negation_again_neutral",586], "RangeForm", {html: construct_dialog("Why was Roger disappointed?", "He didn't go skiing this winter.", "He didn't go skiing again this winter." )}],
[["target_negation_only_positive",504], "RangeForm", {html: construct_dialog("Hannah uses a Mac computer.", "But she doesn't use P.C.", "But she doesn't only use Mac." )}],
[["target_negation_only_neutral",504], "RangeForm", {html: construct_dialog("What are Hannah's computer preferences?", "She doesn't use Mac", "She doesn't only use Mac." )}],
[["target_negation_epistemic_factives_positive",531], "RangeForm", {html: construct_dialog("Liam failed his test last week.", "But he doesn't believe that he failed.", "But he doesn't yet know that he failed." )}],
[["target_negation_epistemic_factives_neutral",531], "RangeForm", {html: construct_dialog("How did Liam react to his test score?", "He can't believe that he failed it.", "He doesn't yet know that he failed." )}],
[["target_negation_stange_change_positive",576], "RangeForm", {html: construct_dialog("Paul was mowing the lawn.", "Even though he saw his favorite show was on, he didn't watch it.", "Even though his favorite show was on, he didn't stop mowing." )}],
[["target_negation_stange_change_neutral",576], "RangeForm", {html: construct_dialog("Paul saw that his favorite show was on TV.", "Even so, he didn't watch it.", "Even so, he didn't stop mowing the lawn." )}],
[["target_negation_stange_change_positive",575], "RangeForm", {html: construct_dialog("Jackson was cleaning out the garage.", "Even though he saw a game was on TV, he didn't watch it.", "Even though he saw that a game was on TV, he didn't stop cleaning." )}],
[["target_negation_stange_change_neutral",575], "RangeForm", {html: construct_dialog("Jackson noticed that a basketball game was on TV.", "Even so, he didn't watch it.", "Even so, he didn't stop cleaning the garage." )}],
[["target_negation_back_positive",569], "RangeForm", {html: construct_dialog("Valerie went to the movies last Saturday. But she has to babysit this weekend.", "So she isn't going to the movies this weekend.", "So she isn't going back to the movies this weekend." )}],
[["target_negation_back_neutral",569], "RangeForm", {html: construct_dialog("Valerie has to babysit this weekend.", "So she didn't go to the movies on Saturday.", "So she didn't go back to the movies on Saturday." )}],
[["target_negation_epistemic_factives_positive",533], "RangeForm", {html: construct_dialog("Ben's dog came down with a bad disease.", "But he doesn't believe that it is very sick.", "But he doesn't yet know that it is very sick." )}],
[["target_negation_epistemic_factives_neutral",533], "RangeForm", {html: construct_dialog("What was Ben's reaction to the vet visit?", "He doesn't believe that his dog is very sick.", "He doesn't yet know that his dog is very sick." )}],
[["target_negation_possessive_positive",551], "RangeForm", {html: construct_dialog("Yesterday, Kira got a new flashlight. When she went for a walk, it was still sunny.", "She didn't take a flashlight with her.", "She didn't take her flashlight with her." )}],
[["target_negation_possessive_neutral",551], "RangeForm", {html: construct_dialog("Why did Kira get lost in the dark?", "She didn't take a flashlight when she went on a walk.", "She didn't take her flashlight when she went on a walk." )}],
[["target_negation_even_positive",508], "RangeForm", {html: construct_dialog("Nell skipped over toppings at the salad bar.", "She didn't get dressing.", "She didn't even get dressing." )}],
[["target_negation_even_neutral",508], "RangeForm", {html: construct_dialog("Why do you think Nell has odd tastes?", "She didn't get dressing at the salad bar.", "She didn't even get dressing at the salad bar." )}],
[["target_negation_question_positive",562], "RangeForm", {html: construct_dialog("Someone stole a package from George's porch.", "He doesn't bother himself wondering if they were caught.", "He doesn't both himself wondering who did it." )}],
[["target_negation_question_neutral",562], "RangeForm", {html: construct_dialog("George is thinking about his deliveries.", "He doesn't both himself wondering if someone stole it from his porch.", "He doesn't bother himself wondering who stole it from his porch." )}],
[["target_base_cognitive_positive",124], "RangeForm", {html: construct_dialog("Desmond stole Jill's guitar.", "She suspects that he stole it.", "She knows he stole it." )}],
[["target_base_cognitive_neutral",124], "RangeForm", {html: construct_dialog("Why is Jill upset?", "She suspects that Desmond stole her guitar.", "She knows that Desmond stole her guitar." )}],
[["target_base_question_embed_positive",160], "RangeForm", {html: construct_dialog("Someone stole Allison's phone.", "She wonders whether they have been caught.", "She wonders who did it." )}],
[["target_base_question_embed_neutral",160], "RangeForm", {html: construct_dialog("Allison can't find her phone.", "She wonders if someone stole it.", "She wonders who stole it." )}],
[["target_base_again_positive",171], "RangeForm", {html: construct_dialog("Kylee went to the post office this morning.", "This afternoon, she went to the bank.", "This afternoon, she went there again." )}],
[["target_base_again_neutral",171], "RangeForm", {html: construct_dialog("What did Kylee do this afternoon?", "She went to the post office.", "She went to the post office again." )}],
[["target_base_only_positive",105], "RangeForm", {html: construct_dialog("Evan went off to the bank.", "On his way, he decided to go the drug store.", "On his way, he decided to go only to the bank." )}],
[["target_base_only_neutral",105], "RangeForm", {html: construct_dialog("What did Evan do this afternoon?", "He went to the bank.", "He went to only the bank." )}],
[["target_base_only_positive",100], "RangeForm", {html: construct_dialog("Alexandra left for the park.", "On her way, she decided to go to the post office.", "On her way, she decided to go only to the park." )}],
[["target_base_only_neutral",100], "RangeForm", {html: construct_dialog("What did Alexandra do last weekend?", "She went to the park.", "She went only to the park." )}],
[["target_base_emotive_positive",135], "RangeForm", {html: construct_dialog("Anna copied Landon's test answers.", "He suspects that she copied them.", "He's mad that she copied them." )}],
[["target_base_emotive_neutral",135], "RangeForm", {html: construct_dialog("What's up with Anna and Landon?", "He suspects that she copied his test answers.", "He's mad that she copied his test answers." )}],
[["target_base_even_positive",108], "RangeForm", {html: construct_dialog("Mira fought hard in her tennis tournament.", "She made it to the final game.", "She even made it to the final game." )}],
[["target_base_even_neutral",108], "RangeForm", {html: construct_dialog("How did Mira do in the tennis tournament?", "She made it to the final game.", "She even made it to the final game." )}],
[["target_base_only_positive",104], "RangeForm", {html: construct_dialog("Paul went off to the basketball court.", "On his way, he decided to go to the park, instead.", "On his way, he decided to go only to the basketball court." )}],
[["target_base_only_neutral",104], "RangeForm", {html: construct_dialog("What did Paul do last weekend?", "He went to the basketball court.", "He went to to only the basketball court." )}],
[["target_base_still_positive",184], "RangeForm", {html: construct_dialog("Norman was reading his book at lunchtime.", "Around three, he was writing a report about it.", "Around three, he was still reading it." )}],
[["target_base_still_neutral",184], "RangeForm", {html: construct_dialog("What was Norman up to?", "Around three, he was reading his book.", "Around three, he was still reading his book." )}],
[["target_base_question_embed_positive",162], "RangeForm", {html: construct_dialog("Someone copied Elise's homework.", "She wonders if they were caught.", "She wonders who did it." )}],
[["target_base_question_embed_neutral",162], "RangeForm", {html: construct_dialog("Elise got a good grade on her homework.", "She wonders if anyone copied it.", "She wonders who copied it." )}],
[["target_base_still_positive",187], "RangeForm", {html: construct_dialog("In the morning, Martin was painting his house.", "In the afternoon, he was mowing the lawn.", "In the afternoon, he was still painting it." )}],
[["target_base_still_neutral",187], "RangeForm", {html: construct_dialog("What is Martin up to?", "He is painting his house.", "He is still painting his house." )}],
[["target_base_back_positive",172], "RangeForm", {html: construct_dialog("Georgia was at her parents house last month. What did she do last week?", "She drove to her parent's house.", "She drove back to her parent's house." )}],
[["target_base_back_neutral",172], "RangeForm", {html: construct_dialog("What did Georgia do last week?", "She drove to her parent's house.", "She drove back to her parent's house." )}],
[["target_base_back_positive",174], "RangeForm", {html: construct_dialog("Harry went to Florida last summer. What about this summer?", "He went to Florida.", "He went back to Florida." )}],
[["target_base_back_neutral",174], "RangeForm", {html: construct_dialog("What did Harry do last summer?", "He went to Florida.", "He went back to Florida." )}],
[["target_base_still_positive",188], "RangeForm", {html: construct_dialog("Valerie went to a protest in the morning.", "In the afternoon, she was at work.", "In the afternoon, she was still at the protest." )}],
[["target_base_still_neutral",188], "RangeForm", {html: construct_dialog("What is Valerie up to?", "She is at a protest.", "She is still at a protest." )}],
   
];


